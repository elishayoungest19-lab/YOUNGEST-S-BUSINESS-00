# YOUNGEST'S BUSINESS – V2 corrigée

Projet Android corrigé pour la construction de l'APK.

## Correction principale
La configuration `compileOptions` a été replacée au bon niveau dans `app/build.gradle`. Elle était auparavant imbriquée dans `defaultConfig`, ce qui empêchait une configuration Gradle Android correcte.

## Configuration
- Application ID: `com.aistudio.youngestbiz.mbkz`
- compileSdk: 35
- targetSdk: 35
- minSdk: 23
- Java: 17
- Android Gradle Plugin: 8.7.3
- Gradle utilisé par GitHub Actions: 8.9

Le workflow `.github/workflows/android.yml` construit automatiquement `app-debug.apk` et l'enregistre comme artefact GitHub Actions.
